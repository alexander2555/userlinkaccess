<?php
$xpdo_meta_map = array (
    'version' => '3.0',
    'namespace' => 'userlinkaccess',
    'namespacePrefix' => '',
    'class_map' => 
    array (
        'xPDO\\Om\\xPDOSimpleObject' => 
        array (
            0 => 'userlinkaccess\\UserLinkAccessLink',
        ),
    ),
);