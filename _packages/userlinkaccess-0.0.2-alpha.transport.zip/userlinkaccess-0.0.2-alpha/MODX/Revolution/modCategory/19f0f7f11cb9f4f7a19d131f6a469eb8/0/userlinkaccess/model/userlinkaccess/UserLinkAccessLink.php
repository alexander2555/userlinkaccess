<?php
namespace userlinkaccess;

use xPDO\xPDO;

/**
 * Class UserLinkAccessLink
 *
 * @property integer $user_id
 * @property integer $resource_id
 * @property string $hash
 * @property integer $created_by
 * @property integer $created_at
 * @property integer $expires_at
 * @property integer $is_active
 * @property string $used
 *
 * @package userlinkaccess
 */
class UserLinkAccessLink extends \xPDO\Om\xPDOSimpleObject
{
}
