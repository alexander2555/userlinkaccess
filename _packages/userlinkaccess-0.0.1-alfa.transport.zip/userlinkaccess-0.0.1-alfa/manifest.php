<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License

Copyright © 2025 AM-Systems. Alexander Mamontov <alexander.m.190180@hotmail.com>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES, OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT, OR OTHERWISE, ARISING FROM, OUT OF, OR IN CONNECTION WITH THE SOFTWARE.
',
    'readme' => '--------------
UserLinkAccess
--------------

Author: Alexander Mamontov <alexander.m.190180@hotmail.com>

UserLinkAccess is a component for MODX 3.x that allows you to grant temporary link access to a resource page.

Installation

Install by package management.
Configure the component parameters from \'userlinkaccess\' namespace if necessary.
Bootstrap is necessary for frontend correct output (https://getbootstrap.com/docs/5.3/getting-started/download/)
It is recommended to install the CSRFHelper package (https://docs.modmore.com/en/Open_Source/CSRFHelper/index.html)

Usage

To directly generate an access link you can use snippet:

[[UserLinkAccess? &resourceId=`10` &lifetime=`3600`]]

Link generating form:

[[$UserLinkAccessFormTpl]]

Also, when creating and deleting a link, the corresponding hooks are executed (by default, these are UserLinkAccessCreateHook and UserLinkAccessDeleteHook snippets).
They can be overridden in the corresponding settings (userlinkaccess.userlinkaccess_create_link_hook, userlinkaccess.userlinkaccess_delete_link_hook).',
    'changelog' => 'Changelog for UserLinkAccess

0.0.1-alpha - 2025-03-15

- First package UserLinkAccess version.
- Temporary access links generating system for resources\' pages.
- AJAX-processor for creating links.
- Connector with csrf-token verification.
- Plugin for handle link-access, snippets, hooks
- Frontend: tpl, js, css



',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '0357c4fcc3708dbb395c5370448a9ea0',
      'native_key' => 'userlinkaccess',
      'filename' => 'MODX/Revolution/modNamespace/7fed5bf7a1838a46dfd8a97474c3643d.vehicle',
      'namespace' => 'userlinkaccess',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'e28484b2e347dae5287683cd1ae0acfc',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modCategory/7d71100b4e6d3e9eaa0b577deaa6f607.vehicle',
      'namespace' => 'userlinkaccess',
    ),
  ),
);